function calcularFrete(){
    window.location.href = "http://localhost:3000/";
}
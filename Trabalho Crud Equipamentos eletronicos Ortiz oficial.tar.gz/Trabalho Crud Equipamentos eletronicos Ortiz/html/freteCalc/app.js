import express from 'express';
import fetch from 'node-fetch';

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));

const apiKey = 'ce529d6a7e8e4650a916d6b772f637c6';

// Função para converter graus para radianos
function degToRad(deg) {
    return deg * (Math.PI / 180);
}

// Função para calcular a distância entre dois pontos (lat1, lon1) e (lat2, lon2)
function calcularDistancia(lat1, lon1, lat2, lon2) {
    const R = 6371; // Raio da Terra em km
    const dLat = degToRad(lat2 - lat1);
    const dLon = degToRad(lon2 - lon1);

    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(degToRad(lat1)) * Math.cos(degToRad(lat2)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distância em km
}

// Função para buscar coordenadas de um endereço
async function obterCoordenadas(endereco) {
    const url = `https://api.opencagedata.com/geocode/v1/json?q=${encodeURIComponent(endereco)}&key=${apiKey}`;
    const response = await fetch(url);
    const data = await response.json();
    if (data.results.length > 0) {
        const { lat, lng } = data.results[0].geometry;
        return { lat, lon: lng };
    }
    throw new Error("Endereço não encontrado");
}

// Função para calcular o valor de frete baseado no peso
function calcularFretePeso(peso) {
    if (peso <= 1) return 10.00;        // Até 1 kg
    if (peso <= 5) return 20.00;        // De 1 a 5 kg
    if (peso <= 10) return 30.00;       // De 5 a 10 kg
    if (peso <= 20) return 50.00;       // De 10 a 20 kg
    return 100.00;                      // Acima de 20 kg
}

// Rota para calcular a distância e o valor do frete
app.post('/calcular-distancia', async (req, res) => {
    try {
        const { endereco1, endereco2, peso, taxaFixaLocal } = req.body;
        const coordenadas1 = await obterCoordenadas(endereco1);
        const coordenadas2 = await obterCoordenadas(endereco2);

        const distancia = calcularDistancia(
            coordenadas1.lat, coordenadas1.lon,
            coordenadas2.lat, coordenadas2.lon
        );

        // Calcula o valor do frete baseado no peso
        const valorFretePeso = calcularFretePeso(peso);

        // Calcula o custo adicional baseado na distância e na taxa fixa local
        const custoAdicional = distancia * taxaFixaLocal;

        // Cálculo final do frete
        const valorFrete = valorFretePeso + custoAdicional;

        res.json({ distancia: distancia.toFixed(2), frete: valorFrete.toFixed(2) });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
